# This Python file is an example of how to add the main code and its attributes to our package. The notation of using src previous to the main package_name directory is standard on Python packages

# NOTE: Edit the name of the 'package_name' folder before adding code
